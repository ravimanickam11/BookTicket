package test

import grails.converters.JSON

class TicketController {

    def index() { 
		
	}
	
	def purchaseTicket() {
		println"Ticket Purchase Start"
		def requestBody = request.JSON
		def from = requestBody.from
		def to = requestBody.to
		def firstName = requestBody.user.firstName
		def lastName = requestBody.user.lastName
		def email = requestBody.user.email
		def price = requestBody.price

		// Allocate seat based on section (simple round-robin allocation)
		def section = (session.ticketCount ?: 0) % 2 == 0 ? "A" : "B"
		def seat = "${section}-${(session.ticketCount ?: 0) + 1}"
		
		// Increment ticket count in session
		session.ticketCount = (session.ticketCount ?: 0) + 1

		def ticket = [
			from: from,
			to: to,
			user: [
				firstName: firstName,
				lastName: lastName,
				email: email
			],
			price: price,
			section: section,
			seat: seat
		]

		// Store ticket in session
		session.tickets = (session.tickets ?: []) + ticket
		println"Ticket Purchase Completed"
		render "Purchase successful. Receipt ID: ${session.tickets.size()}"
	}

	def getReceiptDetails() {
		def requestBody = request.JSON
		def receiptId = requestBody.receiptId
		//def receiptId = params.receiptId 
		println"dddd"+receiptId
		if (receiptId >= 1 && receiptId <= (session.tickets ?: []).size()) {
			render session.tickets[receiptId - 1] as JSON
		} else {
			response.status = 404
			render "Receipt not found"
		}
	}

		
	def getUsersAndSeatsBySection() {
		def requestBody = request.JSON
		def section = requestBody.section
		// Find all tickets in the session with the specified section
		def ticketsInSection = session.tickets.findAll { it.section == section }
		// Extract user and seat information from the tickets
		def usersAndSeats = ticketsInSection.collect { ticket ->
			[user: ticket.user, seat: ticket.seat]
		}
		render usersAndSeats as JSON
	
}
	
	def removeUserFromTrain() {
		def requestBody = request.JSON
		def receiptId = requestBody.receiptId
		if (receiptId >= 1 && receiptId <= (session.tickets ?: []).size()) {
			session.tickets.remove(receiptId - 1)
			render "User removed from the train successfully"
		} else {
			response.status = 404
			render "Receipt not found"
		}
	}

	def modifyUserSeat() {
		def requestBody = request.JSON
		def receiptId = requestBody.receiptId
		def newSeat = request.JSON.seat
		if (receiptId >= 1 && receiptId <= (session.tickets ?: []).size()) {
			session.tickets[receiptId - 1].seat = newSeat
			render "Seat modified successfully"
		} else {
			response.status = 404
			render "Receipt not found"
		}
	}
}

