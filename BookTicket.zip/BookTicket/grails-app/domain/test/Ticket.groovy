package test

class Ticket {
	String from
	String to
	String firstName
	String lastName
	String email
	int price
	String section
	String seat
	
    static constraints = {
		from(nullable: true)
		to(nullable: true)
		firstName(nullable: true)
		lastName(nullable: true)
		email(nullable: true, email: true)
		price(nullable: true)
		section(nullable: true)
		seat(nullable: true)
    }
}
